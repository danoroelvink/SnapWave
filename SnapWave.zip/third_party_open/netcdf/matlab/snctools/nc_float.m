function nc_datatype = nc_float()
% NC_FLOAT:  returns constant corresponding to NC_FLOAT enumerated constant in netcdf.h
%
% USAGE:  nc_datatype = nc_float;
%

nc_datatype = 5;
return

